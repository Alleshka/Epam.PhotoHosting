
create procedure DeleteUser
	@id int
as
	update TUser set isDeleted = 1 where id = @id
GO

