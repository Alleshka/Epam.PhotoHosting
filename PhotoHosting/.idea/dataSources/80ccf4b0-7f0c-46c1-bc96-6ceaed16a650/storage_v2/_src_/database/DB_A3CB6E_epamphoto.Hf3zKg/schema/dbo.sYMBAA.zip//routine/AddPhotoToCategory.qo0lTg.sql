
create procedure AddPhotoToCategory
	@photoID int,
	@categoryID int
as
insert into TCategoryFromPhoto values(@photoID, @categoryID)
GO

