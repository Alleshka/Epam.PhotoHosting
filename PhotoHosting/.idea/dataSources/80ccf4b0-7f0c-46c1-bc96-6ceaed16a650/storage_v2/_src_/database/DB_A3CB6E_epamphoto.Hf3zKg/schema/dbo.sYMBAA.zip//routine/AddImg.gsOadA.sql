
create procedure AddImg
	@bytes varbinary(max),
	@hash nvarchar(max)
as
	insert into TDataPhoto values (@bytes, @hash)
GO

