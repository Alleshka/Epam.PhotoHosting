
create procedure EditCategory
	@id int,
	@newName nvarchar(60)
as
	update TCategory set categoryName = @newName where id = @id
GO

