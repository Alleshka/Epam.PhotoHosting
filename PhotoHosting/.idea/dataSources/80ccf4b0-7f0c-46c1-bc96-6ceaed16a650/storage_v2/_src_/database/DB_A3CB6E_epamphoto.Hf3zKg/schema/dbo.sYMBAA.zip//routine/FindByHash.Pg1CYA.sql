
create procedure FindByHash
	@hash nvarchar(max)
as
	select * from TDataPhoto where @hash = imghash
GO

