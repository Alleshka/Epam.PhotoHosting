
create procedure CreateUser
	@login nvarchar(60),
	@password nvarchar(max)
as
	insert into TUser values (@login, @password, 0)
	select id, userlogin from TUser where userLogin = @login
GO

