
create procedure RemovePhotoFromCategory
	@photoID int,
	@categoryID int
as
	delete from TCategoryFromPhoto where categoryID = @categoryID and photoID = @photoID
GO

