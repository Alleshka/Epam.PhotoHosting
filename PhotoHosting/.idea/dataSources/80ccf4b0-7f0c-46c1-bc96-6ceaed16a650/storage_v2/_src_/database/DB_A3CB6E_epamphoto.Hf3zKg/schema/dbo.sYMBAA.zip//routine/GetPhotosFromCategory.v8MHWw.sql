
create procedure GetPhotosFromCategory
	@id int
as
select * from TCategoryFromPhoto as TC join TPhoto as PH on TC.photoID = PH.id where TC.categoryID = @id
GO

