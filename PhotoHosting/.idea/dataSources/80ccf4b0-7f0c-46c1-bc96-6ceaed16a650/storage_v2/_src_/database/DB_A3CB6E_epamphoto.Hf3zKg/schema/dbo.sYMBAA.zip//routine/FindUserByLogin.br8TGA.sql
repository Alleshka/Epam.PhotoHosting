
create procedure FindUserByLogin
	@login nvarchar(60)
as
	select id, userLogin, isDeleted from TUser where userLogin = @login
GO

