
create procedure DeleteCategory
	@id int
as
	delete from TCategory where id = @id
GO

