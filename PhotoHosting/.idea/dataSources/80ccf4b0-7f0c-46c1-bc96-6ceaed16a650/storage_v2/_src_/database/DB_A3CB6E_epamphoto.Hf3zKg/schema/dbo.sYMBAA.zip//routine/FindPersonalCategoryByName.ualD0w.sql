
create procedure FindPersonalCategoryByName
	@name nvarchar(60),
	@id int
as
	select * from TCategory where categoryName = @name and creator = id
GO

