
create procedure AddPhoto
	@nameimg nvarchar(max),
	@idimg int,
	@idcreator int
as
	insert into TPhoto values (@nameimg, @idimg, @idcreator)
GO

