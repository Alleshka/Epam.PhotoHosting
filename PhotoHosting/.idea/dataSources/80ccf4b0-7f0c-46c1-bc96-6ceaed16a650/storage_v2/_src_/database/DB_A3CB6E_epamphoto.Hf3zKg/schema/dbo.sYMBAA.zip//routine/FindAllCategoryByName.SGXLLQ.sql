
create procedure FindAllCategoryByName
	@name nvarchar(60)
as
	select * from TCategory where categoryName = @name
GO

