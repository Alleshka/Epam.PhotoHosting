
create procedure CreateCategory
	@nameCategory nvarchar(60),
	@creator int
as
	insert into TCategory values (@nameCategory, @creator)
GO

