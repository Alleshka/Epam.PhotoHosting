
create procedure DeletePhoto
	@id int
as
	delete from TPhoto where id = @id
GO

