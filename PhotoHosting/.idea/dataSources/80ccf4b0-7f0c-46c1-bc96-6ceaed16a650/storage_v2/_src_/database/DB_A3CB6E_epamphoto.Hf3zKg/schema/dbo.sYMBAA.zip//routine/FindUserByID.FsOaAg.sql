
create procedure FindUserByID
	@id int
as
	select id, userLogin, isDeleted from TUser where id = @id
GO

