
create procedure GetCategoryList
as
	select * from TCategory
GO

