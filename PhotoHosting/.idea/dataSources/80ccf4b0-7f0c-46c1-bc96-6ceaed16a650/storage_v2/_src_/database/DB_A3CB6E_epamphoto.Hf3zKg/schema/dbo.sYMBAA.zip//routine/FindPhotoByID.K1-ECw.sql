
create procedure FindPhotoByID
	@id int
as
	select * from TPhoto where id = @id
GO

