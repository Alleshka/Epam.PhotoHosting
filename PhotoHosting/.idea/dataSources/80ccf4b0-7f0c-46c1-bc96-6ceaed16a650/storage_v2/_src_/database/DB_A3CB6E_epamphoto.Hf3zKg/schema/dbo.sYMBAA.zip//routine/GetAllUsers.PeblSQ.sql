
create procedure GetAllUsers
as
	select id, userLogin from TUser where isDeleted = 0
GO

