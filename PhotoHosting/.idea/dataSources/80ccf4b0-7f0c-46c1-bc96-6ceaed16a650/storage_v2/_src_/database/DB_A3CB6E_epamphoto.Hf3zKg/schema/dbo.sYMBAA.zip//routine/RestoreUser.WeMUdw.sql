
create procedure RestoreUser
	@id int
as
	update TUser set isDeleted = 0 where id = @id
GO

