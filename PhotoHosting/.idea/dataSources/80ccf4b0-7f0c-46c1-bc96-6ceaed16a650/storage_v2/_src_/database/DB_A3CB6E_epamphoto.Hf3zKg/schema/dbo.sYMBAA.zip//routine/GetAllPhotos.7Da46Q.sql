
create procedure GetAllPhotos
as
	select * from TPhoto
GO

