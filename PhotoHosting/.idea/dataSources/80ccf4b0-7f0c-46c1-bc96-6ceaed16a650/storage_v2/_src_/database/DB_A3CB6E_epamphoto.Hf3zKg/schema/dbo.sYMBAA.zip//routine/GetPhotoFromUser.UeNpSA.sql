
create procedure GetPhotoFromUser
	@id int
as
	select * from TPhoto where uploader = @id
GO

