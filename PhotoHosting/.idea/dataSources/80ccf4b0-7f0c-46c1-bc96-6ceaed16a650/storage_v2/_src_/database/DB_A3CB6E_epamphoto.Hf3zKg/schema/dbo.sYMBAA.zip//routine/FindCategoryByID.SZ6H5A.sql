
create procedure FindCategoryByID
	@id int
as
	select * from TCategory where id = @id
GO

