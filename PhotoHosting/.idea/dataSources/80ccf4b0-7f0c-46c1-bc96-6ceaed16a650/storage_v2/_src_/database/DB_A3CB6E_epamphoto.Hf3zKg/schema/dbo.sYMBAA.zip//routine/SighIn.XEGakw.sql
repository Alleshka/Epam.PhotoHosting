
create procedure SighIn
	@login nvarchar(60),
	@passwod nvarchar(max)
as
	select id, userLogin from TUser where userLogin = @login and userPassword = @passwod
GO

